/* tslint:disable */
/* eslint-disable */
export const main: () => void;
export const __wbg_wbg_rayon_poolbuilder_free: (a: number, b: number) => void;
export const wbg_rayon_poolbuilder_mainJS: (a: number) => any;
export const wbg_rayon_poolbuilder_numThreads: (a: number) => number;
export const wbg_rayon_poolbuilder_receiver: (a: number) => number;
export const wbg_rayon_poolbuilder_build: (a: number) => void;
export const initThreadPool: (a: number) => any;
export const wbg_rayon_start_worker: (a: number) => void;
export const memory: WebAssembly.Memory;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_export_3: WebAssembly.Table;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_export_7: WebAssembly.Table;
export const closure245_externref_shim: (a: number, b: number, c: any) => void;
export const _dyn_core__ops__function__FnMut_____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__hdab81a28dca19707: (a: number, b: number) => void;
export const closure322_externref_shim: (a: number, b: number, c: any) => void;
export const closure359_externref_shim: (a: number, b: number, c: any, d: any) => void;
export const __wbindgen_thread_destroy: (a?: number, b?: number, c?: number) => void;
export const __wbindgen_start: (a: number) => void;
